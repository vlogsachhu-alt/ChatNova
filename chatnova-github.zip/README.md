# ChatNova

**Seedha Chrome mein chalane ke liye:** `index.html` ko Chrome mein kholo (double-click). Bina setup ke *Local demo mode* chalu ho jaata hai: sab features is browser mein chalte hain aur "Demo Friend" (number 919999999999) auto-reply deta hai.
**Asli doston ke saath chat ke liye** neeche wala Firebase setup karo.

# ChatNova — GitHub Pages par chalane ke steps

## 1. Firebase banao (free)
1. https://console.firebase.google.com par jao → **Add project**.
2. **Build → Firestore Database → Create database** (production mode).
3. Firestore ke **Rules** tab mein `firestore.rules` file ka poora content paste karke **Publish** karo.
4. **Build → Authentication → Get started** → **Google** aur **Anonymous** dono enable karo.
5. **Project settings (⚙️) → Your apps → Web (</>)** → app register karo → jo `firebaseConfig` mile uski values `firebase-config.js` mein paste karo.
6. `admins` mein apna Gmail daalo (Admin dashboard ke liye).

## 2. GitHub par daalo
1. GitHub par naya repository banao.
2. Is zip ki saari files (index.html, firebase-config.js, manifest.json, icon.svg, sw.js ...) repo ke root mein upload karo.
3. **Settings → Pages → Source: Deploy from a branch → main / (root) → Save**.
4. Kuch minute baad link milega: `https://USERNAME.github.io/REPO/`

## 3. Firebase mein apna domain allow karo
**Authentication → Settings → Authorized domains → Add domain** → `USERNAME.github.io`

Bas — link kholo, login karo, apna number daalo aur chat shuru. Phone par Chrome menu se **Add to Home screen** karke app jaisa install kar sakte ho.

## Dhyan do (sach)
- **Voice/Video call** sirf local preview hai; asli call ke liye WebRTC + signaling server alag banana padega.
- **End-to-End Encryption** implement nahi hai.
- **Number OTP se verify nahi hota** (SMS ke liye Firebase Phone Auth ya alag backend chahiye).
- **Nova AI** tabhi chalega jab `aiEndpoint` mein tum apna backend doge (API key kabhi page mein mat daalna).
- **Documents upload** ke liye Firebase Storage alag se jodna padega. Photos, DP, status aur voice message bina Storage ke chalte hain.
- Firebase free plan ki limits hain; zyada users par billing lag sakti hai.
