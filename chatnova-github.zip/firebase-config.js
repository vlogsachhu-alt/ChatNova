// Firebase console se apni keys yahan paste karo (README.md dekho)
window.FIREBASE_CONFIG={
  apiKey:"PASTE_API_KEY",
  authDomain:"PASTE_PROJECT.firebaseapp.com",
  projectId:"PASTE_PROJECT_ID",
  appId:"PASTE_APP_ID",
  admins:["your-email@gmail.com"],   // Admin dashboard in logon ko dikhega
  aiEndpoint:""                       // optional: apna AI backend URL (POST {messages} -> {text})
};
